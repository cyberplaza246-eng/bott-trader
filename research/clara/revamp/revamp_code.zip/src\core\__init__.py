"""Initialize core module"""
