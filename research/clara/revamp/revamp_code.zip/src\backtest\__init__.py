"""Initialize backtest module"""
