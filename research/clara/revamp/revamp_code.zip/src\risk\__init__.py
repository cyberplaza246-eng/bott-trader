"""Initialize risk module"""
