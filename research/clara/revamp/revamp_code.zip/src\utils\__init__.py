"""Initialize utils module"""
